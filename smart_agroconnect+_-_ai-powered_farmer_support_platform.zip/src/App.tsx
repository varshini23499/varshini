import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { Dashboard } from "./components/Dashboard";
import { LanguageSetup } from "./components/LanguageSetup";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-green-50 to-blue-50">
      <header className="sticky top-0 z-10 bg-white/90 backdrop-blur-sm h-16 flex justify-between items-center border-b shadow-sm px-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-sm">🌾</span>
          </div>
          <h2 className="text-xl font-bold text-green-800">Smart AgroConnect+</h2>
        </div>
        <Authenticated>
          <SignOutButton />
        </Authenticated>
      </header>
      <main className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-6xl mx-auto">
          <Content />
        </div>
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const farmerProfile = useQuery(api.farmers.getFarmerProfile);

  if (loggedInUser === undefined || farmerProfile === undefined) {
    return (
      <div className="flex justify-center items-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-8">
      <Unauthenticated>
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-6xl font-bold text-green-800 mb-4">
            🌾 Smart AgroConnect+
          </h1>
          <p className="text-xl text-gray-600 mb-2">
            AI-Powered Farmer Support Platform
          </p>
          <p className="text-lg text-gray-500">
            Multilingual • Emergency Support • Investment Guidance
          </p>
        </div>
        <div className="max-w-md mx-auto">
          <SignInForm />
        </div>
      </Unauthenticated>

      <Authenticated>
        {!farmerProfile ? (
          <LanguageSetup />
        ) : (
          <Dashboard farmer={farmerProfile} />
        )}
      </Authenticated>
    </div>
  );
}
