import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface EmergencyCallProps {
  farmer: any;
}

export function EmergencyCall({ farmer }: EmergencyCallProps) {
  const [callType, setCallType] = useState("voice");
  const [issue, setIssue] = useState("");
  const [priority, setPriority] = useState("medium");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const requestCall = useMutation(api.emergency.requestEmergencyCall);
  const emergencyCalls = useQuery(api.emergency.getEmergencyCalls);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!issue.trim()) {
      toast.error("Please describe the issue");
      return;
    }

    setIsSubmitting(true);

    try {
      await requestCall({
        callType,
        issue,
        priority,
      });
      
      toast.success("Emergency call request submitted! An expert will contact you soon.");
      setIssue("");
    } catch (error) {
      toast.error("Failed to submit request");
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getTranslatedText = (text: string, language: string) => {
    const translations: Record<string, Record<string, string>> = {
      "Emergency Expert Support": {
        te: "అత్యవసర నిపుణుల మద్దతు",
        hi: "आपातकालीन विशेषज्ञ सहायता",
        ta: "அவசர நிபுணர் ஆதரவு",
      },
      "Describe your issue": {
        te: "మీ సమస్యను వివరించండి",
        hi: "अपनी समस्या का वर्णन करें",
        ta: "உங்கள் பிரச்சினையை விவரிக்கவும்",
      },
      "Request Call": {
        te: "కాల్ అభ్యర్థన",
        hi: "कॉल का अनुरोध",
        ta: "அழைப்பு கோரிக்கை",
      },
    };
    
    return translations[text]?.[language] || text;
  };

  const priorityColors = {
    low: "bg-green-100 text-green-800",
    medium: "bg-yellow-100 text-yellow-800",
    high: "bg-orange-100 text-orange-800",
    critical: "bg-red-100 text-red-800",
  };

  const statusColors = {
    pending: "bg-yellow-100 text-yellow-800",
    connected: "bg-blue-100 text-blue-800",
    completed: "bg-green-100 text-green-800",
    cancelled: "bg-gray-100 text-gray-800",
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">
        {getTranslatedText("Emergency Expert Support", farmer.preferredLanguage)}
      </h2>
      
      {/* Emergency Call Form */}
      <div className="bg-red-50 border border-red-200 rounded-lg p-6">
        <div className="flex items-center gap-2 mb-4">
          <span className="text-2xl">🚨</span>
          <h3 className="text-lg font-semibold text-red-800">Request Emergency Call</h3>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Call Type
              </label>
              <select
                value={callType}
                onChange={(e) => setCallType(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:border-red-500 focus:ring-1 focus:ring-red-500"
              >
                <option value="voice">Voice Call</option>
                <option value="video">Video Call</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Priority Level
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:border-red-500 focus:ring-1 focus:ring-red-500"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="critical">Critical</option>
              </select>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {getTranslatedText("Describe your issue", farmer.preferredLanguage)}
            </label>
            <textarea
              value={issue}
              onChange={(e) => setIssue(e.target.value)}
              rows={4}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:border-red-500 focus:ring-1 focus:ring-red-500"
              placeholder="Describe the problem you're facing with your crops or farm..."
              required
            />
          </div>
          
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-red-600 text-white py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors disabled:opacity-50"
          >
            {isSubmitting ? "Submitting..." : getTranslatedText("Request Call", farmer.preferredLanguage)}
          </button>
        </form>
      </div>

      {/* Call History */}
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Emergency Calls</h3>
        <div className="space-y-4">
          {emergencyCalls?.map((call) => (
            <div key={call._id} className="bg-white border rounded-lg p-4">
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${priorityColors[call.priority as keyof typeof priorityColors]}`}>
                    {call.priority.toUpperCase()}
                  </span>
                  <span className="text-sm text-gray-600">{call.callType} call</span>
                </div>
                <span className={`px-2 py-1 rounded text-xs font-medium ${statusColors[call.status as keyof typeof statusColors]}`}>
                  {call.status}
                </span>
              </div>
              
              <p className="text-sm text-gray-800 mb-2">{call.issue}</p>
              
              {call.notes && (
                <p className="text-sm text-gray-600 mb-2">
                  <span className="font-medium">Expert Notes:</span> {call.notes}
                </p>
              )}
              
              <p className="text-xs text-gray-500">
                {new Date(call.timestamp).toLocaleString()}
              </p>
            </div>
          ))}
          
          {emergencyCalls?.length === 0 && (
            <p className="text-gray-500 text-center py-8">No emergency calls yet</p>
          )}
        </div>
      </div>
    </div>
  );
}
