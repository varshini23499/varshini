import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

interface GovernmentSchemesProps {
  farmer: any;
}

export function GovernmentSchemes({ farmer }: GovernmentSchemesProps) {
  const schemes = useQuery(api.schemes.getGovernmentSchemes, {
    state: farmer.location.state,
  });

  const getLocalizedContent = (content: any, language: string) => {
    return content[language] || content.en;
  };

  const categoryIcons = {
    subsidy: "💰",
    loan: "🏦",
    insurance: "🛡️",
    training: "📚",
  };

  const categoryColors = {
    subsidy: "bg-green-100 text-green-800 border-green-200",
    loan: "bg-blue-100 text-blue-800 border-blue-200",
    insurance: "bg-purple-100 text-purple-800 border-purple-200",
    training: "bg-orange-100 text-orange-800 border-orange-200",
  };

  const getTranslatedText = (text: string, language: string) => {
    const translations: Record<string, Record<string, string>> = {
      "Government Schemes": {
        te: "ప్రభుత్వ పథకాలు",
        hi: "सरकारी योजनाएं",
        ta: "அரசு திட்டங்கள்",
      },
      "Available for You": {
        te: "మీ కోసం అందుబాటులో",
        hi: "आपके लिए उपलब्ध",
        ta: "உங்களுக்கு கிடைக்கும்",
      },
      "Apply Now": {
        te: "ఇప్పుడే దరఖాస్తు చేయండి",
        hi: "अभी आवेदन करें",
        ta: "இப்போது விண்ணப்பிக்கவும்",
      },
    };
    
    return translations[text]?.[language] || text;
  };

  // Filter schemes by category
  const schemesByCategory = schemes?.reduce((acc, scheme) => {
    if (!acc[scheme.category]) {
      acc[scheme.category] = [];
    }
    acc[scheme.category].push(scheme);
    return acc;
  }, {} as Record<string, any[]>) || {};

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">
        {getTranslatedText("Government Schemes", farmer.preferredLanguage)}
      </h2>
      
      {/* Scheme Categories Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {Object.entries(categoryIcons).map(([category, icon]) => {
          const count = schemesByCategory[category]?.length || 0;
          return (
            <div key={category} className="bg-white border rounded-lg p-4 text-center">
              <span className="text-3xl mb-2 block">{icon}</span>
              <h3 className="font-semibold text-gray-800 capitalize">{category}</h3>
              <p className="text-sm text-gray-600">{count} schemes</p>
            </div>
          );
        })}
      </div>

      {/* Featured Schemes */}
      <div className="bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg p-6">
        <h3 className="text-xl font-semibold mb-4">
          🎯 {getTranslatedText("Available for You", farmer.preferredLanguage)}
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white/10 rounded p-4">
            <h4 className="font-medium mb-2">PM-KISAN Scheme</h4>
            <p className="text-sm text-green-100 mb-2">
              Direct income support of ₹6,000 per year for small and marginal farmers.
            </p>
            <span className="text-xs bg-white/20 px-2 py-1 rounded">Subsidy</span>
          </div>
          <div className="bg-white/10 rounded p-4">
            <h4 className="font-medium mb-2">Crop Insurance Scheme</h4>
            <p className="text-sm text-green-100 mb-2">
              Protect your crops against natural calamities with affordable insurance.
            </p>
            <span className="text-xs bg-white/20 px-2 py-1 rounded">Insurance</span>
          </div>
        </div>
      </div>

      {/* All Schemes by Category */}
      {Object.entries(schemesByCategory).map(([category, categorySchemes]) => (
        <div key={category}>
          <div className="flex items-center gap-3 mb-4">
            <span className="text-2xl">{categoryIcons[category as keyof typeof categoryIcons]}</span>
            <h3 className="text-lg font-semibold text-gray-800 capitalize">{category} Schemes</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {categorySchemes.map((scheme) => (
              <div
                key={scheme._id}
                className={`border rounded-lg p-4 ${categoryColors[category as keyof typeof categoryColors]}`}
              >
                <div className="flex items-start justify-between mb-3">
                  <h4 className="font-semibold">
                    {getLocalizedContent(scheme.name, farmer.preferredLanguage)}
                  </h4>
                  <span className="text-xs px-2 py-1 bg-white/50 rounded capitalize">
                    {scheme.category}
                  </span>
                </div>
                
                <p className="text-sm mb-3">
                  {getLocalizedContent(scheme.description, farmer.preferredLanguage)}
                </p>
                
                <div className="space-y-2 mb-4">
                  <div>
                    <h5 className="text-xs font-medium mb-1">Eligibility:</h5>
                    <p className="text-xs">
                      {getLocalizedContent(scheme.eligibility, farmer.preferredLanguage)}
                    </p>
                  </div>
                  
                  <div>
                    <h5 className="text-xs font-medium mb-1">Benefits:</h5>
                    <p className="text-xs">{scheme.benefits}</p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    {scheme.deadline && (
                      <p className="text-xs">
                        Deadline: {new Date(scheme.deadline).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                  
                  <a
                    href={scheme.applicationLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-white text-gray-800 px-3 py-1 rounded text-xs font-medium hover:bg-gray-50 transition-colors"
                  >
                    {getTranslatedText("Apply Now", farmer.preferredLanguage)}
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}

      {/* No Schemes Message */}
      {schemes?.length === 0 && (
        <div className="text-center py-12">
          <span className="text-6xl mb-4 block">🏛️</span>
          <h3 className="text-lg font-semibold text-gray-600 mb-2">No schemes available</h3>
          <p className="text-gray-500">
            Check back later for new government schemes and programs.
          </p>
        </div>
      )}

      {/* Application Tips */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-yellow-800 mb-4">💡 Application Tips</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white rounded p-4">
            <h4 className="font-medium text-gray-800 mb-2">Required Documents</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Aadhaar Card</li>
              <li>• Land Records (Patta/Khata)</li>
              <li>• Bank Account Details</li>
              <li>• Passport Size Photos</li>
            </ul>
          </div>
          
          <div className="bg-white rounded p-4">
            <h4 className="font-medium text-gray-800 mb-2">Application Process</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Visit the official website</li>
              <li>• Fill the application form</li>
              <li>• Upload required documents</li>
              <li>• Submit and track status</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
