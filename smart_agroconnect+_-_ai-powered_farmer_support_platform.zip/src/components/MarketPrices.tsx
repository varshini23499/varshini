import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

interface MarketPricesProps {
  farmer: any;
}

export function MarketPrices({ farmer }: MarketPricesProps) {
  const marketPrices = useQuery(api.market.getMarketPrices, {
    state: farmer.location.state,
  });

  const getTranslatedText = (text: string, language: string) => {
    const translations: Record<string, Record<string, string>> = {
      "Market Prices": {
        te: "మార్కెట్ ధరలు",
        hi: "बाजार की कीमतें",
        ta: "சந்தை விலைகள்",
      },
      "Today's Prices": {
        te: "నేటి ధరలు",
        hi: "आज की कीमतें",
        ta: "இன்றைய விலைகள்",
      },
    };
    
    return translations[text]?.[language] || text;
  };

  const getPriceChangeColor = (change: number) => {
    if (change > 0) return "text-green-600";
    if (change < 0) return "text-red-600";
    return "text-gray-600";
  };

  const getPriceChangeIcon = (change: number) => {
    if (change > 0) return "📈";
    if (change < 0) return "📉";
    return "➡️";
  };

  const demandSupplyColor = (level: string) => {
    switch (level) {
      case "high": return "bg-green-100 text-green-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "low": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const qualityColor = (quality: string) => {
    switch (quality) {
      case "excellent": return "bg-green-100 text-green-800";
      case "good": return "bg-blue-100 text-blue-800";
      case "average": return "bg-yellow-100 text-yellow-800";
      case "poor": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  // Group prices by crop
  const pricesByCrop = marketPrices?.reduce((acc, price) => {
    if (!acc[price.cropName]) {
      acc[price.cropName] = [];
    }
    acc[price.cropName].push(price);
    return acc;
  }, {} as Record<string, any[]>) || {};

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">
        {getTranslatedText("Market Prices", farmer.preferredLanguage)}
      </h2>
      
      {/* Price Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-r from-green-500 to-green-600 text-white p-6 rounded-lg">
          <h3 className="text-lg font-semibold mb-2">Average Price</h3>
          <p className="text-3xl font-bold">₹2,450</p>
          <p className="text-sm text-green-100">per quintal</p>
        </div>
        
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6 rounded-lg">
          <h3 className="text-lg font-semibold mb-2">Best Market</h3>
          <p className="text-xl font-bold">{farmer.location.district} Mandi</p>
          <p className="text-sm text-blue-100">highest prices today</p>
        </div>
        
        <div className="bg-gradient-to-r from-purple-500 to-purple-600 text-white p-6 rounded-lg">
          <h3 className="text-lg font-semibold mb-2">Price Trend</h3>
          <p className="text-3xl font-bold">+5.2%</p>
          <p className="text-sm text-purple-100">this week</p>
        </div>
      </div>

      {/* Farmer's Crops Prices */}
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">
          {getTranslatedText("Today's Prices", farmer.preferredLanguage)} - Your Crops
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {farmer.primaryCrops.map((cropName: string) => {
            const cropPrices = pricesByCrop[cropName] || [];
            const latestPrice = cropPrices[0];
            
            return (
              <div key={cropName} className="bg-white border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-semibold text-gray-800">{cropName}</h4>
                  <span className="text-2xl">🌾</span>
                </div>
                
                {latestPrice ? (
                  <>
                    <div className="mb-3">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl font-bold text-gray-800">
                          ₹{latestPrice.price.toLocaleString()}
                        </span>
                        <span className="text-sm text-gray-500">per quintal</span>
                      </div>
                      <div className="flex items-center gap-1 mt-1">
                        <span className={getPriceChangeColor(latestPrice.priceChange)}>
                          {getPriceChangeIcon(latestPrice.priceChange)}
                          {Math.abs(latestPrice.priceChange).toFixed(1)}%
                        </span>
                        <span className="text-xs text-gray-500">vs yesterday</span>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Market:</span>
                        <span className="text-sm font-medium">{latestPrice.location.market}</span>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Demand:</span>
                        <span className={`text-xs px-2 py-1 rounded ${demandSupplyColor(latestPrice.demand)}`}>
                          {latestPrice.demand}
                        </span>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Supply:</span>
                        <span className={`text-xs px-2 py-1 rounded ${demandSupplyColor(latestPrice.supply)}`}>
                          {latestPrice.supply}
                        </span>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Quality:</span>
                        <span className={`text-xs px-2 py-1 rounded ${qualityColor(latestPrice.quality)}`}>
                          {latestPrice.quality}
                        </span>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-4">
                    <p className="text-sm text-gray-500">No price data available</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* All Market Prices */}
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">All Market Prices</h3>
        
        <div className="bg-white border rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Crop</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Price (₹/quintal)</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Change</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Market</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Quality</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {marketPrices?.slice(0, 20).map((price) => (
                  <tr key={price._id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 text-sm font-medium text-gray-800">
                      {price.cropName}
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-800">
                      ₹{price.price.toLocaleString()}
                    </td>
                    <td className="px-4 py-3 text-sm">
                      <span className={getPriceChangeColor(price.priceChange)}>
                        {getPriceChangeIcon(price.priceChange)}
                        {Math.abs(price.priceChange).toFixed(1)}%
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600">
                      {price.location.market}
                    </td>
                    <td className="px-4 py-3 text-sm">
                      <span className={`px-2 py-1 rounded text-xs ${qualityColor(price.quality)}`}>
                        {price.quality}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-500">
                      {new Date(price.date).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Price Alerts */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-blue-800 mb-4">💡 Price Insights</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white rounded p-4">
            <h4 className="font-medium text-gray-800 mb-2">Best Time to Sell</h4>
            <p className="text-sm text-gray-600">
              Rice prices are expected to rise by 8-10% in the next 2 weeks due to increased demand.
            </p>
          </div>
          
          <div className="bg-white rounded p-4">
            <h4 className="font-medium text-gray-800 mb-2">Market Recommendation</h4>
            <p className="text-sm text-gray-600">
              {farmer.location.district} Mandi is offering the best prices for your crops this week.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
