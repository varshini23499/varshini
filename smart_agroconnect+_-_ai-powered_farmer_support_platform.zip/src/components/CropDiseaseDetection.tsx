import { useState, useRef } from "react";
import { useMutation, useQuery, useAction } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface CropDiseaseDetectionProps {
  farmer: any;
}

export function CropDiseaseDetection({ farmer }: CropDiseaseDetectionProps) {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [selectedCrop, setSelectedCrop] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const generateUploadUrl = useMutation(api.files.generateUploadUrl);
  const detectDisease = useAction(api.ai.detectCropDisease);
  const detections = useQuery(api.ai.getDiseaseDetections);
  const crops = useQuery(api.farmers.getAllCrops);

  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImage(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedImage || !selectedCrop) {
      toast.error("Please select an image and crop type");
      return;
    }

    setIsUploading(true);
    
    try {
      // Generate upload URL
      const postUrl = await generateUploadUrl();
      
      // Upload image
      const result = await fetch(postUrl, {
        method: "POST",
        headers: { "Content-Type": selectedImage.type },
        body: selectedImage,
      });
      
      const { storageId } = await result.json();
      
      // Detect disease
      const detection = await detectDisease({
        imageId: storageId,
        cropName: selectedCrop,
      });
      
      toast.success("Disease detection completed!");
      setSelectedImage(null);
      setSelectedCrop("");
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    } catch (error) {
      toast.error("Failed to detect disease");
      console.error(error);
    } finally {
      setIsUploading(false);
    }
  };

  const getTranslatedText = (text: string, language: string) => {
    // Simple translation mapping for common terms
    const translations: Record<string, Record<string, string>> = {
      "Upload Image": {
        te: "చిత్రం అప్‌లోడ్ చేయండి",
        hi: "छवि अपलोड करें",
        ta: "படத்தை பதிவேற்றவும்",
      },
      "Select Crop": {
        te: "పంట ఎంచుకోండి",
        hi: "फसल चुनें",
        ta: "பயிரைத் தேர்ந்தெடுக்கவும்",
      },
      "Analyze": {
        te: "విశ్లేషించండి",
        hi: "विश्लेषण करें",
        ta: "பகுப்பாய்வு செய்யவும்",
      },
    };
    
    return translations[text]?.[language] || text;
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">AI Crop Disease Detection</h2>
      
      {/* Upload Form */}
      <div className="bg-gray-50 rounded-lg p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {getTranslatedText("Upload Image", farmer.preferredLanguage)}
            </label>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageSelect}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:border-green-500 focus:ring-1 focus:ring-green-500"
              required
            />
            {selectedImage && (
              <div className="mt-2">
                <img
                  src={URL.createObjectURL(selectedImage)}
                  alt="Selected crop"
                  className="w-32 h-32 object-cover rounded-lg"
                />
              </div>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {getTranslatedText("Select Crop", farmer.preferredLanguage)}
            </label>
            <select
              value={selectedCrop}
              onChange={(e) => setSelectedCrop(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:border-green-500 focus:ring-1 focus:ring-green-500"
              required
            >
              <option value="">Choose crop type</option>
              {farmer.primaryCrops.map((crop: string) => (
                <option key={crop} value={crop}>{crop}</option>
              ))}
            </select>
          </div>
          
          <button
            type="submit"
            disabled={isUploading}
            className="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors disabled:opacity-50"
          >
            {isUploading ? "Analyzing..." : getTranslatedText("Analyze", farmer.preferredLanguage)}
          </button>
        </form>
      </div>

      {/* Detection History */}
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Detections</h3>
        <div className="space-y-4">
          {detections?.map((detection) => (
            <div key={detection._id} className="bg-white border rounded-lg p-4">
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-medium text-gray-800">{detection.cropName}</h4>
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  detection.status === "completed" ? "bg-green-100 text-green-800" :
                  detection.status === "processing" ? "bg-yellow-100 text-yellow-800" :
                  "bg-red-100 text-red-800"
                }`}>
                  {detection.status}
                </span>
              </div>
              
              {detection.detectedDisease && (
                <div className="space-y-2">
                  <p className="text-sm">
                    <span className="font-medium">Disease:</span> {detection.detectedDisease}
                  </p>
                  <p className="text-sm">
                    <span className="font-medium">Confidence:</span> {Math.round((detection.confidence || 0) * 100)}%
                  </p>
                  {detection.aiSuggestions && (
                    <p className="text-sm text-gray-600">{detection.aiSuggestions}</p>
                  )}
                </div>
              )}
              
              <p className="text-xs text-gray-500 mt-2">
                {new Date(detection.timestamp).toLocaleString()}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
