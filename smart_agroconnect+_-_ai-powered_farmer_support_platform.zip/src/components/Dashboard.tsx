import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { CropDiseaseDetection } from "./CropDiseaseDetection";
import { AIChat } from "./AIChat";
import { EmergencyCall } from "./EmergencyCall";
import { WeatherAlerts } from "./WeatherAlerts";
import { MarketPrices } from "./MarketPrices";
import { GovernmentSchemes } from "./GovernmentSchemes";
import { MotivationalContent } from "./MotivationalContent";
import { NotificationCenter } from "./NotificationCenter";

interface DashboardProps {
  farmer: any;
}

const tabs = [
  { id: "overview", name: "Overview", icon: "🏠" },
  { id: "disease", name: "Disease Detection", icon: "🔬" },
  { id: "chat", name: "AI Assistant", icon: "🤖" },
  { id: "emergency", name: "Emergency", icon: "🚨" },
  { id: "weather", name: "Weather", icon: "🌤️" },
  { id: "market", name: "Market", icon: "📈" },
  { id: "schemes", name: "Schemes", icon: "🏛️" },
  { id: "motivation", name: "Motivation", icon: "💪" },
];

export function Dashboard({ farmer }: DashboardProps) {
  const [activeTab, setActiveTab] = useState("overview");
  const notifications = useQuery(api.notifications.getNotifications);

  const getGreeting = (language: string) => {
    const greetings = {
      en: `Welcome back, ${farmer.name}!`,
      te: `తిరిగి స్వాగతం, ${farmer.name}!`,
      hi: `वापसी पर स्वागत है, ${farmer.name}!`,
      ta: `மீண்டும் வரவேற்கிறோம், ${farmer.name}!`,
    };
    return greetings[language as keyof typeof greetings] || greetings.en;
  };

  const unreadCount = notifications?.filter(n => !n.isRead).length || 0;

  return (
    <div className="flex flex-col lg:flex-row gap-6">
      {/* Sidebar */}
      <div className="lg:w-64 bg-white rounded-xl shadow-lg p-4">
        <div className="mb-6">
          <h3 className="font-bold text-lg text-gray-800 mb-2">
            {getGreeting(farmer.preferredLanguage)}
          </h3>
          <div className="text-sm text-gray-600">
            <p>📍 {farmer.location.village}, {farmer.location.district}</p>
            <p>🌾 {farmer.farmSize} acres</p>
            <p>🌱 {farmer.primaryCrops.join(", ")}</p>
          </div>
        </div>

        <nav className="space-y-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${
                activeTab === tab.id
                  ? "bg-green-100 text-green-800 font-medium"
                  : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              <span className="text-lg">{tab.icon}</span>
              <span>{tab.name}</span>
              {tab.id === "overview" && unreadCount > 0 && (
                <span className="ml-auto bg-red-500 text-white text-xs rounded-full px-2 py-1">
                  {unreadCount}
                </span>
              )}
            </button>
          ))}
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 bg-white rounded-xl shadow-lg p-6">
        {activeTab === "overview" && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Dashboard Overview</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="bg-gradient-to-r from-green-500 to-green-600 text-white p-6 rounded-lg">
                <h3 className="text-lg font-semibold mb-2">Farm Size</h3>
                <p className="text-3xl font-bold">{farmer.farmSize} acres</p>
              </div>
              <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6 rounded-lg">
                <h3 className="text-lg font-semibold mb-2">Primary Crops</h3>
                <p className="text-lg">{farmer.primaryCrops.length} varieties</p>
              </div>
              <div className="bg-gradient-to-r from-purple-500 to-purple-600 text-white p-6 rounded-lg">
                <h3 className="text-lg font-semibold mb-2">Notifications</h3>
                <p className="text-3xl font-bold">{unreadCount}</p>
              </div>
            </div>
            <NotificationCenter farmer={farmer} />
          </div>
        )}
        
        {activeTab === "disease" && <CropDiseaseDetection farmer={farmer} />}
        {activeTab === "chat" && <AIChat farmer={farmer} />}
        {activeTab === "emergency" && <EmergencyCall farmer={farmer} />}
        {activeTab === "weather" && <WeatherAlerts farmer={farmer} />}
        {activeTab === "market" && <MarketPrices farmer={farmer} />}
        {activeTab === "schemes" && <GovernmentSchemes farmer={farmer} />}
        {activeTab === "motivation" && <MotivationalContent farmer={farmer} />}
      </div>
    </div>
  );
}
