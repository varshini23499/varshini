import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

interface WeatherAlertsProps {
  farmer: any;
}

export function WeatherAlerts({ farmer }: WeatherAlertsProps) {
  const weatherAlerts = useQuery(api.weather.getWeatherAlerts, {
    state: farmer.location.state,
    district: farmer.location.district,
  });

  const getLocalizedContent = (content: any, language: string) => {
    return content[language] || content.en;
  };

  const severityColors = {
    low: "bg-blue-100 text-blue-800 border-blue-200",
    medium: "bg-yellow-100 text-yellow-800 border-yellow-200",
    high: "bg-orange-100 text-orange-800 border-orange-200",
    critical: "bg-red-100 text-red-800 border-red-200",
  };

  const alertIcons = {
    rain: "🌧️",
    drought: "☀️",
    storm: "⛈️",
    temperature: "🌡️",
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">Weather Alerts & Recommendations</h2>
      
      {/* Current Weather Summary */}
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-lg p-6">
        <div className="flex items-center gap-3 mb-4">
          <span className="text-3xl">🌤️</span>
          <div>
            <h3 className="text-xl font-semibold">Current Weather</h3>
            <p className="text-blue-100">{farmer.location.district}, {farmer.location.state}</p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <p className="text-2xl font-bold">28°C</p>
            <p className="text-sm text-blue-100">Temperature</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold">65%</p>
            <p className="text-sm text-blue-100">Humidity</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold">12 km/h</p>
            <p className="text-sm text-blue-100">Wind Speed</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold">20%</p>
            <p className="text-sm text-blue-100">Rain Chance</p>
          </div>
        </div>
      </div>

      {/* Active Alerts */}
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Active Weather Alerts</h3>
        
        {weatherAlerts && weatherAlerts.length > 0 ? (
          <div className="space-y-4">
            {weatherAlerts.map((alert) => (
              <div
                key={alert._id}
                className={`border rounded-lg p-4 ${severityColors[alert.severity as keyof typeof severityColors]}`}
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl">
                    {alertIcons[alert.alertType as keyof typeof alertIcons] || "⚠️"}
                  </span>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-semibold capitalize">{alert.alertType} Alert</h4>
                      <span className="px-2 py-1 rounded text-xs font-medium bg-white/50">
                        {alert.severity.toUpperCase()}
                      </span>
                    </div>
                    
                    <p className="mb-3">
                      {getLocalizedContent(alert.message, farmer.preferredLanguage)}
                    </p>
                    
                    <div className="bg-white/30 rounded p-3">
                      <h5 className="font-medium mb-1">Recommendations:</h5>
                      <p className="text-sm">
                        {getLocalizedContent(alert.recommendations, farmer.preferredLanguage)}
                      </p>
                    </div>
                    
                    <p className="text-xs mt-2 opacity-75">
                      Valid until: {new Date(alert.validUntil).toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
            <span className="text-4xl mb-2 block">✅</span>
            <h4 className="font-semibold text-green-800 mb-1">No Active Alerts</h4>
            <p className="text-green-600">Weather conditions are favorable for farming activities.</p>
          </div>
        )}
      </div>

      {/* 7-Day Forecast */}
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">7-Day Forecast</h3>
        <div className="grid grid-cols-1 md:grid-cols-7 gap-2">
          {Array.from({ length: 7 }, (_, i) => {
            const date = new Date();
            date.setDate(date.getDate() + i);
            const isToday = i === 0;
            
            return (
              <div key={i} className="bg-white border rounded-lg p-3 text-center">
                <p className="text-sm font-medium text-gray-600 mb-1">
                  {isToday ? "Today" : date.toLocaleDateString('en', { weekday: 'short' })}
                </p>
                <div className="text-2xl mb-2">
                  {i % 3 === 0 ? "☀️" : i % 3 === 1 ? "⛅" : "🌧️"}
                </div>
                <p className="text-sm">
                  <span className="font-semibold">{28 + Math.floor(Math.random() * 8)}°</span>
                  <span className="text-gray-500">/{20 + Math.floor(Math.random() * 5)}°</span>
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  {Math.floor(Math.random() * 40)}% rain
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
