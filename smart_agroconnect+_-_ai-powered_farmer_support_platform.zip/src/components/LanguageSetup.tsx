import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

const languages = [
  { code: "en", name: "English", nativeName: "English" },
  { code: "te", name: "Telugu", nativeName: "తెలుగు" },
  { code: "hi", name: "Hindi", nativeName: "हिंदी" },
  { code: "ta", name: "Tamil", nativeName: "தமிழ்" },
];

const states = [
  "Andhra Pradesh", "Telangana", "Karnataka", "Tamil Nadu", "Kerala",
  "Maharashtra", "Gujarat", "Rajasthan", "Punjab", "Haryana",
  "Uttar Pradesh", "Bihar", "West Bengal", "Odisha", "Madhya Pradesh"
];

const crops = [
  "Rice", "Wheat", "Cotton", "Sugarcane", "Maize", "Soybean",
  "Groundnut", "Sunflower", "Chilli", "Turmeric", "Tomato", "Onion"
];

export function LanguageSetup() {
  const [selectedLanguage, setSelectedLanguage] = useState("en");
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    state: "",
    district: "",
    village: "",
    farmSize: "",
    primaryCrops: [] as string[],
  });

  const createProfile = useMutation(api.farmers.createFarmerProfile);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.phone || !formData.state || !formData.district || !formData.village || !formData.farmSize) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      await createProfile({
        name: formData.name,
        phone: formData.phone,
        location: {
          state: formData.state,
          district: formData.district,
          village: formData.village,
        },
        preferredLanguage: selectedLanguage,
        farmSize: parseFloat(formData.farmSize),
        primaryCrops: formData.primaryCrops,
      });
      
      toast.success("Profile created successfully!");
    } catch (error) {
      toast.error("Failed to create profile");
      console.error(error);
    }
  };

  const toggleCrop = (crop: string) => {
    setFormData(prev => ({
      ...prev,
      primaryCrops: prev.primaryCrops.includes(crop)
        ? prev.primaryCrops.filter(c => c !== crop)
        : [...prev.primaryCrops, crop]
    }));
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg p-8">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-green-800 mb-2">Welcome to Smart AgroConnect+</h2>
        <p className="text-gray-600">Let's set up your farmer profile</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Language Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">
            Choose your preferred language / भाषा चुनें / భాష ఎంచుకోండి / மொழியைத் தேர்ந்தெடுக்கவும்
          </label>
          <div className="grid grid-cols-2 gap-3">
            {languages.map((lang) => (
              <button
                key={lang.code}
                type="button"
                onClick={() => setSelectedLanguage(lang.code)}
                className={`p-4 rounded-lg border-2 text-center transition-all ${
                  selectedLanguage === lang.code
                    ? "border-green-500 bg-green-50 text-green-800"
                    : "border-gray-200 hover:border-green-300"
                }`}
              >
                <div className="font-semibold">{lang.nativeName}</div>
                <div className="text-sm text-gray-500">{lang.name}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Personal Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Full Name *
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-green-500 focus:ring-1 focus:ring-green-500 outline-none"
              placeholder="Enter your full name"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Phone Number *
            </label>
            <input
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-green-500 focus:ring-1 focus:ring-green-500 outline-none"
              placeholder="+91 9876543210"
              required
            />
          </div>
        </div>

        {/* Location */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              State *
            </label>
            <select
              value={formData.state}
              onChange={(e) => setFormData(prev => ({ ...prev, state: e.target.value }))}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-green-500 focus:ring-1 focus:ring-green-500 outline-none"
              required
            >
              <option value="">Select State</option>
              {states.map(state => (
                <option key={state} value={state}>{state}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              District *
            </label>
            <input
              type="text"
              value={formData.district}
              onChange={(e) => setFormData(prev => ({ ...prev, district: e.target.value }))}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-green-500 focus:ring-1 focus:ring-green-500 outline-none"
              placeholder="Enter district"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Village *
            </label>
            <input
              type="text"
              value={formData.village}
              onChange={(e) => setFormData(prev => ({ ...prev, village: e.target.value }))}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-green-500 focus:ring-1 focus:ring-green-500 outline-none"
              placeholder="Enter village"
              required
            />
          </div>
        </div>

        {/* Farm Size */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Farm Size (in acres) *
          </label>
          <input
            type="number"
            step="0.1"
            value={formData.farmSize}
            onChange={(e) => setFormData(prev => ({ ...prev, farmSize: e.target.value }))}
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-green-500 focus:ring-1 focus:ring-green-500 outline-none"
            placeholder="e.g., 2.5"
            required
          />
        </div>

        {/* Primary Crops */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">
            Primary Crops (select multiple)
          </label>
          <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
            {crops.map(crop => (
              <button
                key={crop}
                type="button"
                onClick={() => toggleCrop(crop)}
                className={`p-2 rounded-lg border text-sm transition-all ${
                  formData.primaryCrops.includes(crop)
                    ? "border-green-500 bg-green-50 text-green-800"
                    : "border-gray-200 hover:border-green-300"
                }`}
              >
                {crop}
              </button>
            ))}
          </div>
        </div>

        <button
          type="submit"
          className="w-full bg-green-600 text-white py-4 rounded-lg font-semibold hover:bg-green-700 transition-colors"
        >
          Create Profile & Continue
        </button>
      </form>
    </div>
  );
}
