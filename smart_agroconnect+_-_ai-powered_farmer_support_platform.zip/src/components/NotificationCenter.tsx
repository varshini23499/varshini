import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface NotificationCenterProps {
  farmer: any;
}

export function NotificationCenter({ farmer }: NotificationCenterProps) {
  const notifications = useQuery(api.notifications.getNotifications);
  const markAsRead = useMutation(api.notifications.markNotificationAsRead);

  const handleMarkAsRead = async (notificationId: any) => {
    try {
      await markAsRead({ notificationId });
    } catch (error) {
      toast.error("Failed to mark notification as read");
    }
  };

  const typeIcons = {
    weather: "🌤️",
    scheme: "🏛️",
    market: "📈",
    motivation: "💪",
    emergency: "🚨",
  };

  const priorityColors = {
    low: "border-l-blue-500",
    medium: "border-l-yellow-500",
    high: "border-l-orange-500",
  };

  const unreadNotifications = notifications?.filter(n => !n.isRead) || [];
  const readNotifications = notifications?.filter(n => n.isRead) || [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-800">Notifications</h3>
        {unreadNotifications.length > 0 && (
          <span className="bg-red-500 text-white text-xs rounded-full px-2 py-1">
            {unreadNotifications.length} new
          </span>
        )}
      </div>

      {/* Unread Notifications */}
      {unreadNotifications.length > 0 && (
        <div className="space-y-3">
          <h4 className="font-medium text-gray-700">New Notifications</h4>
          {unreadNotifications.map((notification) => (
            <div
              key={notification._id}
              className={`bg-white border-l-4 ${priorityColors[notification.priority as keyof typeof priorityColors]} rounded-r-lg p-4 shadow-sm cursor-pointer hover:shadow-md transition-shadow`}
              onClick={() => handleMarkAsRead(notification._id)}
            >
              <div className="flex items-start gap-3">
                <span className="text-xl">
                  {typeIcons[notification.type as keyof typeof typeIcons] || "📢"}
                </span>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h5 className="font-medium text-gray-800">{notification.title}</h5>
                    <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">
                      NEW
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{notification.message}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500">
                      {new Date(notification.timestamp).toLocaleString()}
                    </span>
                    <span className={`text-xs px-2 py-1 rounded ${
                      notification.priority === 'high' ? 'bg-red-100 text-red-800' :
                      notification.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-blue-100 text-blue-800'
                    }`}>
                      {notification.priority.toUpperCase()}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Read Notifications */}
      {readNotifications.length > 0 && (
        <div className="space-y-3">
          <h4 className="font-medium text-gray-700">Previous Notifications</h4>
          <div className="max-h-64 overflow-y-auto space-y-2">
            {readNotifications.slice(0, 10).map((notification) => (
              <div
                key={notification._id}
                className="bg-gray-50 border rounded-lg p-3 opacity-75"
              >
                <div className="flex items-start gap-3">
                  <span className="text-lg opacity-60">
                    {typeIcons[notification.type as keyof typeof typeIcons] || "📢"}
                  </span>
                  <div className="flex-1">
                    <h5 className="font-medium text-gray-700 text-sm">{notification.title}</h5>
                    <p className="text-xs text-gray-600 mb-1">{notification.message}</p>
                    <span className="text-xs text-gray-500">
                      {new Date(notification.timestamp).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Empty State */}
      {notifications?.length === 0 && (
        <div className="text-center py-8">
          <span className="text-4xl mb-2 block">📭</span>
          <h4 className="font-medium text-gray-600 mb-1">No notifications yet</h4>
          <p className="text-sm text-gray-500">
            You'll receive updates about weather, market prices, and government schemes here.
          </p>
        </div>
      )}

      {/* Quick Actions */}
      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
        <h4 className="font-medium text-green-800 mb-2">Stay Updated</h4>
        <p className="text-sm text-green-700 mb-3">
          Get personalized notifications about weather alerts, market prices, and government schemes.
        </p>
        <div className="flex flex-wrap gap-2">
          <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">Weather Alerts</span>
          <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">Market Updates</span>
          <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">Scheme Notifications</span>
          <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">Expert Tips</span>
        </div>
      </div>
    </div>
  );
}
