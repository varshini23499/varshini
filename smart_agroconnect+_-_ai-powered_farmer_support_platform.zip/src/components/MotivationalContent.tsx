import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

interface MotivationalContentProps {
  farmer: any;
}

export function MotivationalContent({ farmer }: MotivationalContentProps) {
  const motivationalContent = useQuery(api.motivation.getMotivationalContent, {});

  const getLocalizedContent = (content: any, language: string) => {
    return content[language] || content.en;
  };

  const typeIcons = {
    story: "📖",
    video: "🎥",
    tip: "💡",
    quote: "💬",
  };

  const categoryColors = {
    success: "bg-green-100 text-green-800 border-green-200",
    innovation: "bg-blue-100 text-blue-800 border-blue-200",
    sustainability: "bg-emerald-100 text-emerald-800 border-emerald-200",
    community: "bg-purple-100 text-purple-800 border-purple-200",
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">Motivational Content</h2>
      
      {/* Featured Quote */}
      <div className="bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg p-6">
        <div className="flex items-center gap-3 mb-4">
          <span className="text-3xl">💪</span>
          <div>
            <h3 className="text-xl font-semibold">Daily Motivation</h3>
            <p className="text-green-100">Inspiration for today</p>
          </div>
        </div>
        
        <blockquote className="text-lg italic mb-4">
          "The farmer is the only man in our economy who buys everything at retail, sells everything at wholesale, and pays the freight both ways."
        </blockquote>
        <p className="text-green-100">- John F. Kennedy</p>
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {motivationalContent?.map((content) => (
          <div
            key={content._id}
            className={`border rounded-lg p-4 ${categoryColors[content.category as keyof typeof categoryColors] || "bg-gray-100 text-gray-800 border-gray-200"}`}
          >
            <div className="flex items-start gap-3 mb-3">
              <span className="text-2xl">
                {typeIcons[content.type as keyof typeof typeIcons] || "📄"}
              </span>
              <div className="flex-1">
                <h4 className="font-semibold mb-1">
                  {getLocalizedContent(content.title, farmer.preferredLanguage)}
                </h4>
                <span className="px-2 py-1 rounded text-xs font-medium bg-white/50 capitalize">
                  {content.category}
                </span>
              </div>
            </div>
            
            <p className="text-sm mb-3">
              {getLocalizedContent(content.content, farmer.preferredLanguage)}
            </p>
            
            {content.author && (
              <p className="text-xs opacity-75">- {content.author}</p>
            )}
            
            {content.videoUrl && (
              <div className="mt-3">
                <a
                  href={content.videoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-sm font-medium hover:underline"
                >
                  🎥 Watch Video
                </a>
              </div>
            )}
            
            <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/30">
              <span className="text-xs opacity-75">{content.type}</span>
              <div className="flex items-center gap-1">
                <span className="text-sm">❤️</span>
                <span className="text-xs">{content.likes}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Success Stories Section */}
      <div className="bg-white border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Success Stories from Your Region</h3>
        
        <div className="space-y-4">
          <div className="border-l-4 border-green-500 pl-4">
            <h4 className="font-medium text-gray-800">Increased Yield with Smart Irrigation</h4>
            <p className="text-sm text-gray-600 mb-2">
              Farmer Ravi from {farmer.location.district} increased his crop yield by 40% using drip irrigation and soil sensors.
            </p>
            <p className="text-xs text-gray-500">2 days ago</p>
          </div>
          
          <div className="border-l-4 border-blue-500 pl-4">
            <h4 className="font-medium text-gray-800">Organic Farming Success</h4>
            <p className="text-sm text-gray-600 mb-2">
              Sunita Devi transitioned to organic farming and now sells premium produce at 50% higher prices.
            </p>
            <p className="text-xs text-gray-500">1 week ago</p>
          </div>
          
          <div className="border-l-4 border-purple-500 pl-4">
            <h4 className="font-medium text-gray-800">Community Farming Initiative</h4>
            <p className="text-sm text-gray-600 mb-2">
              A group of 20 farmers in {farmer.location.state} formed a cooperative and reduced input costs by 30%.
            </p>
            <p className="text-xs text-gray-500">2 weeks ago</p>
          </div>
        </div>
      </div>

      {/* Tips Section */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-yellow-800 mb-4">💡 Today's Farming Tips</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white rounded p-4">
            <h4 className="font-medium text-gray-800 mb-2">Soil Health</h4>
            <p className="text-sm text-gray-600">
              Test your soil pH regularly. Most crops prefer a pH between 6.0-7.0 for optimal nutrient uptake.
            </p>
          </div>
          
          <div className="bg-white rounded p-4">
            <h4 className="font-medium text-gray-800 mb-2">Water Management</h4>
            <p className="text-sm text-gray-600">
              Water your crops early morning or late evening to reduce evaporation and maximize absorption.
            </p>
          </div>
          
          <div className="bg-white rounded p-4">
            <h4 className="font-medium text-gray-800 mb-2">Pest Control</h4>
            <p className="text-sm text-gray-600">
              Use neem oil as a natural pesticide. It's effective against many pests and safe for beneficial insects.
            </p>
          </div>
          
          <div className="bg-white rounded p-4">
            <h4 className="font-medium text-gray-800 mb-2">Crop Rotation</h4>
            <p className="text-sm text-gray-600">
              Rotate legumes with cereals to naturally fix nitrogen in the soil and improve fertility.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
