import { useState, useRef, useEffect } from "react";
import { useAction, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface AIChatProps {
  farmer: any;
}

export function AIChat({ farmer }: AIChatProps) {
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const chatWithAI = useAction(api.ai.chatWithAI);
  const chatSession = useQuery(api.ai.getActiveChatSession);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatSession?.messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!message.trim()) return;

    setIsLoading(true);
    const userMessage = message;
    setMessage("");

    try {
      await chatWithAI({
        message: userMessage,
        language: farmer.preferredLanguage,
      });
    } catch (error) {
      toast.error("Failed to send message");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const getPlaceholder = (language: string) => {
    const placeholders = {
      en: "Ask about crops, weather, diseases, or market prices...",
      te: "పంటలు, వాతావరణం, వ్యాధులు లేదా మార్కెట్ ధరల గురించి అడగండి...",
      hi: "फसलों, मौसम, बीमारियों या बाजार की कीमतों के बारे में पूछें...",
      ta: "பயிர்கள், வானிலை, நோய்கள் அல்லது சந்தை விலைகள் பற்றி கேளுங்கள்...",
    };
    return placeholders[language as keyof typeof placeholders] || placeholders.en;
  };

  return (
    <div className="flex flex-col h-96">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">AI Assistant</h2>
      
      {/* Chat Messages */}
      <div className="flex-1 bg-gray-50 rounded-lg p-4 overflow-y-auto mb-4">
        {chatSession?.messages.length === 0 ? (
          <div className="text-center text-gray-500 mt-8">
            <p>👋 Hello! I'm your AI farming assistant.</p>
            <p className="text-sm mt-2">Ask me anything about farming, crops, weather, or market prices!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {chatSession?.messages.map((msg, index) => (
              <div
                key={index}
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                    msg.role === "user"
                      ? "bg-green-600 text-white"
                      : "bg-white text-gray-800 border"
                  }`}
                >
                  <p className="text-sm">{msg.content}</p>
                  <p className="text-xs opacity-70 mt-1">
                    {new Date(msg.timestamp).toLocaleTimeString()}
                  </p>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white text-gray-800 border px-4 py-2 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-green-600"></div>
                    <span className="text-sm">AI is thinking...</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder={getPlaceholder(farmer.preferredLanguage)}
          className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:border-green-500 focus:ring-1 focus:ring-green-500 outline-none"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading || !message.trim()}
          className="px-6 py-3 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-colors disabled:opacity-50"
        >
          Send
        </button>
      </form>
    </div>
  );
}
