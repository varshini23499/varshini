import { action, mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api } from "./_generated/api";

export const detectCropDisease = action({
  args: {
    imageId: v.id("_storage"),
    cropName: v.string(),
  },
  handler: async (ctx, args): Promise<{
    detectionId: any;
    detectedDisease: string;
    confidence: number;
    suggestions: string;
  }> => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const farmer: any = await ctx.runQuery(api.farmers.getFarmerProfile);
    if (!farmer) {
      throw new Error("Farmer profile not found");
    }

    // Create detection record
    const detectionId: any = await ctx.runMutation(api.ai.createDiseaseDetection, {
      farmerId: farmer._id,
      imageId: args.imageId,
      cropName: args.cropName,
    });

    try {
      // Simulate AI disease detection (replace with actual AI service)
      const mockDiseases = [
        "Leaf Blight", "Powdery Mildew", "Rust", "Bacterial Spot", "Viral Mosaic"
      ];
      const detectedDisease = mockDiseases[Math.floor(Math.random() * mockDiseases.length)];
      const confidence = Math.random() * 0.3 + 0.7; // 70-100% confidence

      const suggestions = `Detected: ${detectedDisease}. Treatment: Apply appropriate fungicide, ensure proper drainage, remove affected leaves, and maintain field hygiene.`;

      // Update detection with results
      await ctx.runMutation(api.ai.updateDiseaseDetection, {
        detectionId,
        detectedDisease,
        confidence,
        aiSuggestions: suggestions,
        status: "completed",
      });

      return {
        detectionId,
        detectedDisease,
        confidence,
        suggestions,
      };
    } catch (error) {
      await ctx.runMutation(api.ai.updateDiseaseDetection, {
        detectionId,
        status: "failed",
      });
      throw error;
    }
  },
});

export const createDiseaseDetection = mutation({
  args: {
    farmerId: v.id("farmers"),
    imageId: v.id("_storage"),
    cropName: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("diseaseDetections", {
      ...args,
      status: "processing",
      timestamp: Date.now(),
    });
  },
});

export const updateDiseaseDetection = mutation({
  args: {
    detectionId: v.id("diseaseDetections"),
    detectedDisease: v.optional(v.string()),
    confidence: v.optional(v.number()),
    aiSuggestions: v.optional(v.string()),
    status: v.string(),
  },
  handler: async (ctx, args) => {
    const { detectionId, ...updates } = args;
    return await ctx.db.patch(detectionId, updates);
  },
});

export const getDiseaseDetections = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const farmer = await ctx.db
      .query("farmers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!farmer) {
      return [];
    }

    return await ctx.db
      .query("diseaseDetections")
      .withIndex("by_farmer", (q) => q.eq("farmerId", farmer._id))
      .order("desc")
      .take(20);
  },
});

export const chatWithAI = action({
  args: {
    message: v.string(),
    language: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const farmer = await ctx.runQuery(api.farmers.getFarmerProfile);
    if (!farmer) {
      throw new Error("Farmer profile not found");
    }

    // Get or create chat session
    let chatSession = await ctx.runQuery(api.ai.getActiveChatSession);
    if (!chatSession) {
      chatSession = await ctx.runMutation(api.ai.createChatSession, {
        farmerId: farmer._id,
      });
    }

    if (!chatSession) {
      throw new Error("Failed to create chat session");
    }

    // Add user message
    await ctx.runMutation(api.ai.addChatMessage, {
      sessionId: chatSession._id,
      role: "user",
      content: args.message,
      language: args.language,
    });

    // Generate AI response (mock implementation)
    const aiResponse = await generateAIResponse(args.message, args.language, farmer);

    // Add AI response
    await ctx.runMutation(api.ai.addChatMessage, {
      sessionId: chatSession._id,
      role: "assistant",
      content: aiResponse,
      language: args.language,
    });

    return aiResponse;
  },
});

async function generateAIResponse(message: string, language: string, farmer: any): Promise<string> {
  // Mock AI responses based on common farming queries
  const responses = {
    en: {
      weather: "Based on current weather patterns, I recommend checking soil moisture and adjusting irrigation accordingly.",
      disease: "For disease prevention, ensure proper crop rotation and use certified seeds.",
      market: "Current market prices are favorable for your primary crops. Consider harvesting soon.",
      default: "I'm here to help with your farming questions. You can ask about crops, weather, diseases, or market prices.",
    },
    te: {
      weather: "ప్రస్తుత వాతావరణ పరిస్థితుల ఆధారంగా, మట్టిలో తేమను తనిఖీ చేసి, నీటిపారుదలను సర్దుబాటు చేయాలని సిఫార్సు చేస్తున్నాను.",
      disease: "వ్యాధి నివారణ కోసం, సరైన పంట మార్పిడిని నిర్ధారించండి మరియు ధృవీకరించబడిన విత్తనాలను ఉపయోగించండి.",
      market: "మీ ప్రధాన పంటలకు ప్రస్తుత మార్కెట్ ధరలు అనుకూలంగా ఉన్నాయి. త్వరలో కోత పంట గురించి ఆలోచించండి.",
      default: "మీ వ్యవసాయ ప్రశ్నలతో సహాయం చేయడానికి నేను ఇక్కడ ఉన్నాను. మీరు పంటలు, వాతావరణం, వ్యాధులు లేదా మార్కెట్ ధరల గురించి అడగవచ్చు.",
    },
    hi: {
      weather: "वर्तमान मौसम पैटर्न के आधार पर, मैं मिट्टी की नमी की जांच करने और तदनुसार सिंचाई को समायोजित करने की सलाह देता हूं।",
      disease: "रोग की रोकथाम के लिए, उचित फसल चक्र सुनिश्चित करें और प्रमाणित बीजों का उपयोग करें।",
      market: "आपकी प्राथमिक फसलों के लिए वर्तमान बाजार मूल्य अनुकूल हैं। जल्द ही कटाई पर विचार करें।",
      default: "मैं आपके कृषि प्रश्नों में मदद के लिए यहां हूं। आप फसलों, मौसम, बीमारियों या बाजार की कीमतों के बारे में पूछ सकते हैं।",
    },
    ta: {
      weather: "தற்போதைய வானிலை முறைகளின் அடிப்படையில், மண்ணின் ஈரப்பதத்தை சரிபார்த்து, அதற்கேற்ப நீர்ப்பாசனத்தை சரிசெய்ய பரிந்துரைக்கிறேன்.",
      disease: "நோய் தடுப்புக்காக, சரியான பயிர் சுழற்சியை உறுதி செய்து, சான்றளிக்கப்பட்ட விதைகளைப் பயன்படுத்துங்கள்.",
      market: "உங்கள் முதன்மை பயிர்களுக்கு தற்போதைய சந்தை விலைகள் சாதகமாக உள்ளன. விரைவில் அறுவடை செய்வதைக் கருத்தில் கொள்ளுங்கள்.",
      default: "உங்கள் விவசாய கேள்விகளுக்கு உதவ நான் இங்கே இருக்கிறேன். நீங்கள் பயிர்கள், வானிலை, நோய்கள் அல்லது சந்தை விலைகள் பற்றி கேட்கலாம்.",
    },
  };

  const langResponses = responses[language as keyof typeof responses] || responses.en;
  
  if (message.toLowerCase().includes('weather') || message.toLowerCase().includes('వాతావరణ') || message.toLowerCase().includes('मौसम') || message.toLowerCase().includes('வானிலை')) {
    return langResponses.weather;
  } else if (message.toLowerCase().includes('disease') || message.toLowerCase().includes('వ్యాధి') || message.toLowerCase().includes('रोग') || message.toLowerCase().includes('நோய்')) {
    return langResponses.disease;
  } else if (message.toLowerCase().includes('price') || message.toLowerCase().includes('market') || message.toLowerCase().includes('ధర') || message.toLowerCase().includes('मूल्य') || message.toLowerCase().includes('விலை')) {
    return langResponses.market;
  }
  
  return langResponses.default;
}

export const getActiveChatSession = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const farmer = await ctx.db
      .query("farmers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!farmer) {
      return null;
    }

    return await ctx.db
      .query("chatSessions")
      .withIndex("by_farmer", (q) => q.eq("farmerId", farmer._id))
      .filter((q) => q.eq(q.field("isActive"), true))
      .first();
  },
});

export const createChatSession = mutation({
  args: {
    farmerId: v.id("farmers"),
  },
  handler: async (ctx, args) => {
    const sessionId = await ctx.db.insert("chatSessions", {
      farmerId: args.farmerId,
      messages: [],
      isActive: true,
    });

    return await ctx.db.get(sessionId);
  },
});

export const addChatMessage = mutation({
  args: {
    sessionId: v.id("chatSessions"),
    role: v.string(),
    content: v.string(),
    language: v.string(),
  },
  handler: async (ctx, args) => {
    const session = await ctx.db.get(args.sessionId);
    if (!session) {
      throw new Error("Chat session not found");
    }

    const newMessage = {
      role: args.role,
      content: args.content,
      timestamp: Date.now(),
      language: args.language,
    };

    const updatedMessages = [...session.messages, newMessage];

    return await ctx.db.patch(args.sessionId, {
      messages: updatedMessages,
    });
  },
});
