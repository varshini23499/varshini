import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const getWeatherAlerts = query({
  args: {
    state: v.string(),
    district: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("weatherAlerts")
      .withIndex("by_location", (q) => 
        q.eq("location.state", args.state).eq("location.district", args.district)
      )
      .filter((q) => q.eq(q.field("isActive"), true))
      .filter((q) => q.gt(q.field("validUntil"), Date.now()))
      .collect();
  },
});

export const createWeatherAlert = mutation({
  args: {
    location: v.object({
      state: v.string(),
      district: v.string(),
    }),
    alertType: v.string(),
    severity: v.string(),
    message: v.object({
      en: v.string(),
      te: v.string(),
      hi: v.string(),
      ta: v.string(),
    }),
    recommendations: v.object({
      en: v.string(),
      te: v.string(),
      hi: v.string(),
      ta: v.string(),
    }),
    validUntil: v.number(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("weatherAlerts", {
      ...args,
      isActive: true,
    });
  },
});
