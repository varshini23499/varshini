import { query } from "./_generated/server";
import { v } from "convex/values";

export const getMotivationalContent = query({
  args: {
    type: v.optional(v.string()),
    category: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    let content;

    if (args.type) {
      content = await ctx.db
        .query("motivationalContent")
        .withIndex("by_type", (q) => q.eq("type", args.type!))
        .filter((q) => q.eq(q.field("isActive"), true))
        .collect();
    } else {
      content = await ctx.db
        .query("motivationalContent")
        .filter((q) => q.eq(q.field("isActive"), true))
        .collect();
    }

    if (args.category) {
      content = content.filter(item => item.category === args.category);
    }

    return content.sort(() => Math.random() - 0.5).slice(0, 10);
  },
});
