import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getNotifications = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const farmer = await ctx.db
      .query("farmers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!farmer) {
      return [];
    }

    return await ctx.db
      .query("notifications")
      .withIndex("by_farmer", (q) => q.eq("farmerId", farmer._id))
      .order("desc")
      .take(20);
  },
});

export const markNotificationAsRead = mutation({
  args: {
    notificationId: v.id("notifications"),
  },
  handler: async (ctx, args) => {
    return await ctx.db.patch(args.notificationId, {
      isRead: true,
    });
  },
});

export const createNotification = mutation({
  args: {
    farmerId: v.id("farmers"),
    type: v.string(),
    title: v.string(),
    message: v.string(),
    language: v.string(),
    priority: v.string(),
    actionUrl: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("notifications", {
      ...args,
      isRead: false,
      timestamp: Date.now(),
    });
  },
});
