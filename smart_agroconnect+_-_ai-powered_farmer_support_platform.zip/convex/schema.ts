import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  farmers: defineTable({
    userId: v.id("users"),
    name: v.string(),
    phone: v.string(),
    location: v.object({
      state: v.string(),
      district: v.string(),
      village: v.string(),
      coordinates: v.optional(v.object({
        lat: v.number(),
        lng: v.number(),
      })),
    }),
    preferredLanguage: v.string(), // "en", "te", "hi", "ta"
    farmSize: v.number(), // in acres
    primaryCrops: v.array(v.string()),
    registrationDate: v.number(),
  }).index("by_user", ["userId"]),

  crops: defineTable({
    name: v.string(),
    nameTranslations: v.object({
      en: v.string(),
      te: v.string(),
      hi: v.string(),
      ta: v.string(),
    }),
    category: v.string(), // "cereal", "pulse", "vegetable", "fruit", "cash_crop"
    season: v.string(), // "kharif", "rabi", "zaid"
    avgPrice: v.number(), // per quintal
    diseases: v.array(v.object({
      name: v.string(),
      symptoms: v.string(),
      treatment: v.string(),
    })),
  }).index("by_category", ["category"]),

  diseaseDetections: defineTable({
    farmerId: v.id("farmers"),
    imageId: v.id("_storage"),
    cropName: v.string(),
    detectedDisease: v.optional(v.string()),
    confidence: v.optional(v.number()),
    aiSuggestions: v.optional(v.string()),
    status: v.string(), // "processing", "completed", "failed"
    timestamp: v.number(),
  }).index("by_farmer", ["farmerId"]),

  weatherAlerts: defineTable({
    location: v.object({
      state: v.string(),
      district: v.string(),
    }),
    alertType: v.string(), // "rain", "drought", "storm", "temperature"
    severity: v.string(), // "low", "medium", "high", "critical"
    message: v.object({
      en: v.string(),
      te: v.string(),
      hi: v.string(),
      ta: v.string(),
    }),
    recommendations: v.object({
      en: v.string(),
      te: v.string(),
      hi: v.string(),
      ta: v.string(),
    }),
    validUntil: v.number(),
    isActive: v.boolean(),
  }).index("by_location", ["location.state", "location.district"]),

  governmentSchemes: defineTable({
    name: v.object({
      en: v.string(),
      te: v.string(),
      hi: v.string(),
      ta: v.string(),
    }),
    description: v.object({
      en: v.string(),
      te: v.string(),
      hi: v.string(),
      ta: v.string(),
    }),
    eligibility: v.object({
      en: v.string(),
      te: v.string(),
      hi: v.string(),
      ta: v.string(),
    }),
    benefits: v.string(),
    applicationLink: v.string(),
    deadline: v.optional(v.number()),
    targetStates: v.array(v.string()),
    category: v.string(), // "subsidy", "loan", "insurance", "training"
    isActive: v.boolean(),
  }).index("by_category", ["category"]),

  chatSessions: defineTable({
    farmerId: v.id("farmers"),
    messages: v.array(v.object({
      role: v.string(), // "user", "assistant"
      content: v.string(),
      timestamp: v.number(),
      language: v.string(),
    })),
    topic: v.optional(v.string()),
    isActive: v.boolean(),
  }).index("by_farmer", ["farmerId"]),

  emergencyCalls: defineTable({
    farmerId: v.id("farmers"),
    expertId: v.optional(v.string()),
    callType: v.string(), // "voice", "video"
    issue: v.string(),
    priority: v.string(), // "low", "medium", "high", "critical"
    status: v.string(), // "pending", "connected", "completed", "cancelled"
    scheduledTime: v.optional(v.number()),
    duration: v.optional(v.number()),
    notes: v.optional(v.string()),
    timestamp: v.number(),
  }).index("by_farmer", ["farmerId"]),

  marketPrices: defineTable({
    cropName: v.string(),
    location: v.object({
      state: v.string(),
      district: v.string(),
      market: v.string(),
    }),
    price: v.number(), // per quintal
    priceChange: v.number(), // percentage change from previous day
    demand: v.string(), // "low", "medium", "high"
    supply: v.string(), // "low", "medium", "high"
    quality: v.string(), // "poor", "average", "good", "excellent"
    date: v.number(),
  }).index("by_crop_location", ["cropName", "location.state"]),

  investments: defineTable({
    farmerId: v.id("farmers"),
    type: v.string(), // "seeds", "fertilizer", "equipment", "irrigation"
    item: v.string(),
    amount: v.number(),
    expectedROI: v.number(),
    actualROI: v.optional(v.number()),
    status: v.string(), // "planned", "invested", "completed"
    notes: v.optional(v.string()),
    timestamp: v.number(),
  }).index("by_farmer", ["farmerId"]),

  motivationalContent: defineTable({
    type: v.string(), // "story", "video", "tip", "quote"
    title: v.object({
      en: v.string(),
      te: v.string(),
      hi: v.string(),
      ta: v.string(),
    }),
    content: v.object({
      en: v.string(),
      te: v.string(),
      hi: v.string(),
      ta: v.string(),
    }),
    author: v.optional(v.string()),
    imageId: v.optional(v.id("_storage")),
    videoUrl: v.optional(v.string()),
    category: v.string(), // "success", "innovation", "sustainability", "community"
    likes: v.number(),
    isActive: v.boolean(),
  }).index("by_type", ["type"]),

  farmRecords: defineTable({
    farmerId: v.id("farmers"),
    season: v.string(),
    year: v.number(),
    cropData: v.array(v.object({
      cropName: v.string(),
      area: v.number(), // in acres
      seedVariety: v.string(),
      plantingDate: v.number(),
      harvestDate: v.optional(v.number()),
      yield: v.optional(v.number()), // in quintals
      totalCost: v.number(),
      revenue: v.optional(v.number()),
      profit: v.optional(v.number()),
    })),
    soilTestResults: v.optional(v.object({
      pH: v.number(),
      nitrogen: v.number(),
      phosphorus: v.number(),
      potassium: v.number(),
      organicMatter: v.number(),
      testDate: v.number(),
    })),
    notes: v.optional(v.string()),
  }).index("by_farmer_year", ["farmerId", "year"]),

  notifications: defineTable({
    farmerId: v.id("farmers"),
    type: v.string(), // "weather", "scheme", "market", "motivation", "emergency"
    title: v.string(),
    message: v.string(),
    language: v.string(),
    priority: v.string(), // "low", "medium", "high"
    isRead: v.boolean(),
    actionUrl: v.optional(v.string()),
    timestamp: v.number(),
  }).index("by_farmer", ["farmerId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
