import { query } from "./_generated/server";
import { v } from "convex/values";

export const getGovernmentSchemes = query({
  args: {
    category: v.optional(v.string()),
    state: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    let schemes;

    if (args.category) {
      schemes = await ctx.db
        .query("governmentSchemes")
        .withIndex("by_category", (q) => q.eq("category", args.category!))
        .filter((q) => q.eq(q.field("isActive"), true))
        .collect();
    } else {
      schemes = await ctx.db
        .query("governmentSchemes")
        .filter((q) => q.eq(q.field("isActive"), true))
        .collect();
    }

    if (args.state) {
      schemes = schemes.filter(scheme => 
        scheme.targetStates.includes(args.state!) || scheme.targetStates.includes("all")
      );
    }

    return schemes;
  },
});
