import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const getMarketPrices = query({
  args: {
    cropName: v.optional(v.string()),
    state: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    if (args.cropName && args.state) {
      return await ctx.db
        .query("marketPrices")
        .withIndex("by_crop_location", (q) => 
          q.eq("cropName", args.cropName!).eq("location.state", args.state!)
        )
        .order("desc")
        .take(50);
    }

    return await ctx.db.query("marketPrices").order("desc").take(50);
  },
});

export const addMarketPrice = mutation({
  args: {
    cropName: v.string(),
    location: v.object({
      state: v.string(),
      district: v.string(),
      market: v.string(),
    }),
    price: v.number(),
    priceChange: v.number(),
    demand: v.string(),
    supply: v.string(),
    quality: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("marketPrices", {
      ...args,
      date: Date.now(),
    });
  },
});
