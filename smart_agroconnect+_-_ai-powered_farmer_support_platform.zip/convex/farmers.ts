import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createFarmerProfile = mutation({
  args: {
    name: v.string(),
    phone: v.string(),
    location: v.object({
      state: v.string(),
      district: v.string(),
      village: v.string(),
      coordinates: v.optional(v.object({
        lat: v.number(),
        lng: v.number(),
      })),
    }),
    preferredLanguage: v.string(),
    farmSize: v.number(),
    primaryCrops: v.array(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const existingFarmer = await ctx.db
      .query("farmers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (existingFarmer) {
      throw new Error("Farmer profile already exists");
    }

    return await ctx.db.insert("farmers", {
      userId,
      ...args,
      registrationDate: Date.now(),
    });
  },
});

export const getFarmerProfile = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    return await ctx.db
      .query("farmers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();
  },
});

export const updateFarmerProfile = mutation({
  args: {
    name: v.optional(v.string()),
    phone: v.optional(v.string()),
    location: v.optional(v.object({
      state: v.string(),
      district: v.string(),
      village: v.string(),
      coordinates: v.optional(v.object({
        lat: v.number(),
        lng: v.number(),
      })),
    })),
    preferredLanguage: v.optional(v.string()),
    farmSize: v.optional(v.number()),
    primaryCrops: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const farmer = await ctx.db
      .query("farmers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!farmer) {
      throw new Error("Farmer profile not found");
    }

    const updates = Object.fromEntries(
      Object.entries(args).filter(([_, value]) => value !== undefined)
    );

    return await ctx.db.patch(farmer._id, updates);
  },
});

export const getAllCrops = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("crops").collect();
  },
});

export const getCropsByCategory = query({
  args: { category: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("crops")
      .withIndex("by_category", (q) => q.eq("category", args.category))
      .collect();
  },
});
