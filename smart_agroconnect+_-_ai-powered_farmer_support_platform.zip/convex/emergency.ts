import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const requestEmergencyCall = mutation({
  args: {
    callType: v.string(),
    issue: v.string(),
    priority: v.string(),
    scheduledTime: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User not authenticated");
    }

    const farmer = await ctx.db
      .query("farmers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!farmer) {
      throw new Error("Farmer profile not found");
    }

    return await ctx.db.insert("emergencyCalls", {
      farmerId: farmer._id,
      callType: args.callType,
      issue: args.issue,
      priority: args.priority,
      scheduledTime: args.scheduledTime,
      status: "pending",
      timestamp: Date.now(),
    });
  },
});

export const getEmergencyCalls = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const farmer = await ctx.db
      .query("farmers")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!farmer) {
      return [];
    }

    return await ctx.db
      .query("emergencyCalls")
      .withIndex("by_farmer", (q) => q.eq("farmerId", farmer._id))
      .order("desc")
      .take(10);
  },
});

export const updateCallStatus = mutation({
  args: {
    callId: v.id("emergencyCalls"),
    status: v.string(),
    expertId: v.optional(v.string()),
    duration: v.optional(v.number()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { callId, ...updates } = args;
    return await ctx.db.patch(callId, updates);
  },
});
